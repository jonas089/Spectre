CORION contracts, originally from

https://github.com/CORIONplatform/solidity

String utilities, originally from

https://github.com/Arachnid/solidity-stringutils

